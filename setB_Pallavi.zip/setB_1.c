#include<stdio.h>
#include<string.h>

char a[100];
void reduce(int i)
{
  for(;a[i]!='\0';)
   {
     a[i]=a[i+2];
     a[i+1]=a[i+3];
     i+=2;
   }
}
int main()
 {
      int i=0,len=0;
      printf("enter the string: ");
      scanf("%s",a);
         for(int i=0;a[len]!='\0';len++)
         for(int i=0;i<len;)
     {
         if((a[i] == a[i+1]) && (i>=0) && a[i]!= '\0')
       {
         reduce(i);
         i--;
       }
else
       {
         i++;
       }
     } 
   if(a[0] == '\0')
   printf("Empty String\n");
else
   printf("%s\n",a);
return 0;
 }
